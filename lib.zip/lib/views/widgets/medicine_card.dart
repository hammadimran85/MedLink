import 'package:flutter/material.dart';
import 'package:med_link/cart_screen.dart';
import 'package:med_link/views/screens/details/details_screen.dart';

class MedicineCard extends StatefulWidget {
  const MedicineCard({super.key, required this.isFav});

  final bool isFav;

  @override
  State<MedicineCard> createState() => _MedicineCardState();
}

class _MedicineCardState extends State<MedicineCard> {
  bool isSelected = false;

  @override
  void initState() {
    super.initState();
    isSelected = widget.isFav;
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const DetailsScreen()));
      },
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(width: 1.0, color: Colors.black12),
          color: const Color.fromARGB(255, 255, 255, 251),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  width: 10,
                ),
                Image.asset(
                  'assets/images/vaccine.png',
                  width: 70,
                ),
                IconButton(
                    onPressed: () {
                      setState(() {
                        isSelected = !isSelected;
                      });
                      ScaffoldMessenger.of(context).clearSnackBars();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(isSelected
                              ? 'Added as a Favorite!'
                              : 'Removed as a Favorite!'),
                        ),
                      );
                    },
                    icon: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 500),
                      transitionBuilder: (child, animation) {
                        return RotationTransition(
                          turns: Tween<double>(
                            begin: 0.5,
                            end: 1,
                          ).animate(animation),
                          child: child,
                        );
                      },
                      child: Icon(
                        isSelected ? Icons.favorite : Icons.favorite_border,
                        color: isSelected ? Colors.red : Colors.black26,
                        key: ValueKey(isSelected),
                      ),
                    )),
              ],
            ),
            const Text(
              'Abacavir (also called Ziagen)',
              style: TextStyle(
                  fontSize: 14,
                  color: Colors.black,
                  fontWeight: FontWeight.w500),
            ),
            const SizedBox(
              height: 10,
            ),
            const Text(
              '600 Rs',
              style: TextStyle(
                  fontSize: 18,
                  color: Color.fromRGBO(88, 87, 219, 1),
                  fontWeight: FontWeight.w500),
            ),
            const SizedBox(
              height: 5,
            ),
            Container(
              width: 150,
              height: 40,
              decoration: BoxDecoration(
                  color: const Color.fromRGBO(11, 171, 124, 1),
                  borderRadius: BorderRadius.circular(10)),
              child: TextButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const CartScreen()));
                  },
                  child: const Text(
                    'Add to Cart',
                    style: TextStyle(
                        fontSize: 14,
                        color: Colors.white,
                        fontWeight: FontWeight.w500),
                  )),
            )
          ],
        ),
      ),
    );
  }
}
