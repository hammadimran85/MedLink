import 'package:flutter/material.dart';
import 'package:med_link/views/screens/medicines.dart';

class CategoryCardsHorizontal extends StatefulWidget {
  const CategoryCardsHorizontal({super.key});

  @override
  State<CategoryCardsHorizontal> createState() => _CategoryCardState();
}

class _CategoryCardState extends State<CategoryCardsHorizontal> {
  bool isSelected = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        InkWell(
          onTap: () {
            setState(() {
              isSelected = !isSelected;
            });
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => const MedicineBookmarkScreen(
                          screenTitle: 'Medicine',
                          isMedicine: true,
                        )));
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            margin: const EdgeInsets.only(bottom: 7, right: 10, left: 7),
            padding: const EdgeInsets.all(5),
            decoration: BoxDecoration(
              border: Border.all(
                  width: 1.0,
                  color: isSelected
                      ? const Color.fromRGBO(11, 171, 124, 1)
                      : Colors.black26),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Image.asset(
              'assets/images/medicine.png',
              width: 70,
            ),
          ),
        ),
        const Text(
          'Medicines',
          style: TextStyle(
              fontSize: 12, color: Colors.black, fontWeight: FontWeight.w600),
        )
      ],
    );
  }
}
