import 'package:flutter/material.dart';

class MedicineCardSmall extends StatelessWidget {
  const MedicineCardSmall({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 130,
      margin: const EdgeInsets.only(right: 5, left: 5),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(width: 1.0, color: Colors.black12),
        color: const Color.fromARGB(255, 255, 255, 251),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(
                width: 10,
              ),
              Image.asset(
                'assets/images/vaccine.png',
                width: 40,
              ),
              const Icon(
                Icons.favorite_border_outlined,
                size: 18,
              ),
            ],
          ),
          const Text(
            'Abacavir (also called Ziagen)',
            style: TextStyle(
                fontSize: 10, color: Colors.black, fontWeight: FontWeight.w500),
          ),
          const SizedBox(
            height: 5,
          ),
          const Text(
            '600 Rs',
            style: TextStyle(
                fontSize: 12,
                color: Color.fromRGBO(88, 87, 219, 1),
                fontWeight: FontWeight.w500),
          ),
          const SizedBox(
            height: 5,
          ),
          Container(
            width: 100,
            height: 25,
            decoration: BoxDecoration(
                color: const Color.fromRGBO(11, 171, 124, 1),
                borderRadius: BorderRadius.circular(5)),
            child: TextButton(
                onPressed: () {},
                child: const Text(
                  'Add to Cart',
                  style: TextStyle(
                      fontSize: 8,
                      color: Colors.white,
                      fontWeight: FontWeight.w500),
                )),
          )
        ],
      ),
    );
  }
}
