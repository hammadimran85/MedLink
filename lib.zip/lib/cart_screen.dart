import 'package:flutter/material.dart';
import 'package:med_link/checkout_screen.dart'; // Import your checkout_screen.dart file

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cart'),
        actions: [
          IconButton(
            icon: const Icon(Icons.code),
            onPressed: () {
              // Display codbanner.png
            },
          ),
        ],
      ),
      body: ListView(
        children: [
          ListTile(
            leading: Image.asset('assets/vaccine.png'),
            title: const Text('Viral Vaccine'),
            subtitle: const Text('Rs 600'),
            trailing: const Text('1'),
          ),
          ListTile(
            leading: Image.asset('assets/vaccine.png'),
            title: const Text('Viral Vaccine'),
            subtitle: const Text('Rs 600'),
            trailing: const Text('1'),
          ),
          ListTile(
            leading: Image.asset('assets/images/vaccine.png'),
            title: const Text('Viral Vaccine'),
            subtitle: const Text('Rs 600'),
            trailing: const Text('1'),
          ),
          const ListTile(
            title: Text('Order Total:'),
            subtitle: Text('Rs 2000'),
            trailing: Text('Free'),
          ),
          ListTile(
            title: const Text('Cash on Delivery'),
            leading: Image.asset('assets/codbanner.png'),
          ),
        ],
      ),
      bottomNavigationBar: ElevatedButton(
        onPressed: () {
          // Navigate to checkout_screen.dart when button is pressed
          Navigator.pushNamed(context, '/checkout');
        },
        child: const Text('Proceed to Checkout'),
      ),
    );
  }
}
